#!/usr/bin/env bash

hg archive ~/Desktop/badwolf.zip -I 'colors' -I README.markdown -I 'contrib'
