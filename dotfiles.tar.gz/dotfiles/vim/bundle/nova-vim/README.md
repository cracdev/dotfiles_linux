# nova-vim

Nova color scheme plugin for Vim

![Screenshot](/assets/screenshot.png?raw=true "Screenshot")

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md)

## More info

**See the [documentation website](https://trevordmiller.github.io/nova) for more information**
