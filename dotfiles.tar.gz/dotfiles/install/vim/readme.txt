
# vundler install
git clone https://github.com/VundleVim/Vundle.vim.git ~/dotfiles/vim/bundle/Vundle.vim

#Launch vim and run
:PluginInstall

# To install from command line:
vim +PluginInstall +qall
