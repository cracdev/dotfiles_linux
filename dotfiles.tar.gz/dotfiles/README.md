Dotfiles
===============

This repository contains personal dotfiles

Installation
------------
Just clone the repo then 

Add vundle
------------
Run ``git clone https://github.com/gmarik/Vundle.vim.git vim/bundle/vundle`` into the cloned dotfiles repo to have the latest vim vunlde 

Create Symlinks
------------
Run ``./makesymlinks.sh`` to make symlinks of the dotfiles.

Install vundle pluggins
------------
vim +PluginInstall
